import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber1L;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Put your name here
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model, NNCalcView view) {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers
         */
        NaturalNumber topNumber = model.top();
        NaturalNumber bottomNumber = model.bottom();

        /*
         * Updates display for the top and bottom frames
         */
        view.updateBottomDisplay(bottomNumber);
        view.updateBottomDisplay(topNumber);

        final int maxNumber = 2147483647;

        NaturalNumber zero = new NaturalNumber1L();
        NaturalNumber maxInt = new NaturalNumber1L(maxNumber);
        NaturalNumber two = new NaturalNumber1L(2);

        boolean allowed = false;

        /*
         * Checks to make sure the top number is greater than the bottom number
         */
        if (topNumber.compareTo(bottomNumber) > 0) {

            allowed = true;

            view.updateSubtractAllowed(allowed);
        } else {
            allowed = false;

            view.updateSubtractAllowed(allowed);
        }

        /*
         * Makes sure that the bottom number is not 0 as you can't divide
         * anything by 0
         */
        if (bottomNumber.compareTo(zero) > 0) {

            allowed = true;

            view.updateDivideAllowed(allowed);
        } else {
            allowed = false;

            view.updateDivideAllowed(allowed);
        }

        /*
         * Makes sure that the bottom number is less than or equal to the max
         * integer
         */
        if (bottomNumber.compareTo(maxInt) <= 0) {
            allowed = true;

            view.updatePowerAllowed(allowed);
        } else {
            allowed = false;

            view.updatePowerAllowed(allowed);
        }

        /*
         * Makes sure that the bottom number is greater or equal to 2 or less
         * than or equal to the integer max
         */
        if (bottomNumber.compareTo(two) >= 0 && bottomNumber.compareTo(maxInt) <= 0) {
            allowed = true;

            view.updateRootAllowed(allowed);
        } else {
            allowed = false;

            view.updateRootAllowed(allowed);
        }
        view.updateTopDisplay(topNumber);
        view.updateBottomDisplay(bottomNumber);

    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers
         */
        NaturalNumber topNumber = this.model.top();
        NaturalNumber bottomNumber = this.model.bottom();

        /*
         * Changes top frame to have the number of the bottom frame
         */
        topNumber.copyFrom(bottomNumber);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddEvent() {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers
         */
        NaturalNumber topNumber = this.model.top();
        NaturalNumber bottomNumber = this.model.bottom();

        /*
         * Adds the number from the bottom frame to the number in the top frame
         */
        topNumber.add(bottomNumber);
        bottomNumber.transferFrom(topNumber);

        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processSubtractEvent() {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers
         */
        NaturalNumber topNumber = this.model.top();
        NaturalNumber bottomNumber = this.model.bottom();

        /*
         * Subtracts the number from the bottom frame to the number in the top
         * frame
         */
        topNumber.subtract(bottomNumber);
        bottomNumber.transferFrom(topNumber);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processMultiplyEvent() {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers
         */
        NaturalNumber topNumber = this.model.top();
        NaturalNumber bottomNumber = this.model.bottom();

        /*
         * Multiplies the number from the bottom frame to the number in the top
         * frame
         */
        topNumber.multiply(bottomNumber);
        bottomNumber.transferFrom(topNumber);

        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processDivideEvent() {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers
         */
        NaturalNumber topNumber = this.model.top();
        NaturalNumber bottomNumber = this.model.bottom();

        /*
         * First finds the remainder from dividing the top number from the
         * bottom number and prints that on the top frame and prints the
         * quotient to the bottom frame
         */
        NaturalNumber remainder = topNumber.divide(bottomNumber);
        bottomNumber.transferFrom(topNumber);
        topNumber.copyFrom(remainder);

        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processPowerEvent() {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers and converts the
         * bottom number to an integer
         */
        NaturalNumber topNumber = this.model.top();
        NaturalNumber bottomNumber = this.model.bottom();
        int powerNumber = bottomNumber.toInt();

        /*
         * Takes the power of the topNumber^bottomNumber and puts it in the top
         * frame
         */
        topNumber.power(powerNumber);
        bottomNumber.transferFrom(topNumber);

        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processRootEvent() {

        /*
         * stores topNumber and bottomNumber as NaturalNumbers and converts the
         * bottom number to an integer
         */
        NaturalNumber topNumber = this.model.top();
        NaturalNumber bottomNumber = this.model.bottom();
        int rootNumber = bottomNumber.toInt();

        /*
         * Takes the root of bottomNumber to the topNumber and puts it in the
         * top frame
         */
        topNumber.power(rootNumber);
        bottomNumber.transferFrom(topNumber);

        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddNewDigitEvent(int digit) {

        /*
         * stores bottomNumber as NaturalNumbers
         */
        NaturalNumber bottomNumber = this.model.bottom();

        /*
         * Every time a user presses a new number it adds it at the end of the
         * original number
         */
        bottomNumber.multiplyBy10(digit);

        updateViewToMatchModel(this.model, this.view);

    }

}
